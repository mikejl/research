
# Turn off scinot
options(scipen=999)

# ############### Library loading ################

library(lattice)
library(grid)
library(ggplot2)
library(graph)
library (plyr)

# ################ Functions #####################

# Trim blanks
trim <- function (x) gsub("^\\s+|\\s+$", "", x)
clearspace <- function(x) gsub("^[[:space:]]+|[[:space:]]+$", "", x) 

# ################# End functions ##################

whitespace <- " \t\n\r\v\f"

# Set WD
dir <- '/Users/mike/results/'
setwd(dir)


library(xlsx)
#dev.off()

siidata <- read.xlsx("SII-prefdata.xlsx", 1)
siidata$Testnum <- as.factor(siidata$Testnum)

siismry <- ddply(siidata, .var =c("Function", "Testnum"), 
                 summarise, countavg = mean(Count), 
                 timeavg = mean(Time.sec.), callsavg = mean(Calls))

siismry2 <- ddply(siidata, .var =c("Function"), 
                 summarise, countavg = mean(Count), 
                 timeavg = mean(Time.sec.), callsavg = mean(Calls))

hist(siismry2$timeavg)
grid()

barplot(siismry2$timeavg, 
        main="Function Calls", xlab="Avg Time", log = "y")

boxplot(siismry2$timeavg ~ siismry2$Function, data = siismry2,
        xlab = "Function", main = "SII Time by Function", col = "red", cex.axis = 0.75)

barchart(siismry2$timeavg ~ siismry2$Function, data = siismry2,
xlab = "Function", ylab = "Time(sec)", main = "SII Time by Function", col = "grey", cex.axis = 0.75)
grid()

pareto.chart(siismry2$timeavg, main="time")

# Dynamic charts
library(rCharts)
library(base64enc)

n2 <- nPlot(timeavg ~ Function, group = "Function", 
            data = siismry2, type = "multiBarChart")
n2$save('sii-smry.html', standalone = TRUE)

# Create chart
h1 <- hPlot(x = "Function", y = "timeavg", data = siismry2, type = c("column"))
h1$save('sii-smry2.html', standalone = TRUE)

h2 <- hPlot(x = "Time.sec.", y = "Calls", data = siidata, 
            type = c("line", "bubble", "scatter"), group = "Function", size = "Count")
h2$save('sii-scatter.html', standalone = TRUE)


r1 <- rPlot(timeavg ~ Testnum | Function + callsavg, data = siismry, type = "point", color = "gear")
r1$save('sii-smry3.html', standalone = TRUE)

